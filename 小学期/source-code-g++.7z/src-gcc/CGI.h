#pragma once
#include <string>
#include <iostream>
namespace CGI
{
  
  // 输出CGI必要的HTTP头文件 及HTML描述文件头部
  inline void outHead(std::string str,int score) {
    printf("Content-type:text/html\n\n");
    std::cout << R"(<html> 
<head> 
<meta charset="utf-8" /> 
<title>C++消消乐</title> 
<style> 
body{
    background-color: #CCCCCC;
    background-image: url('bg.png');
    background-repeat: no-repeat;
    background-attachment: fixed; 
    background-size: cover;
}
.cen{ text-align:center;font-weight:500;} 
.div{     position: absolute;
    margin-top: 50px;
    width: 550px;
    left: 50%;
    margin-left: -275px;}
.button{margin-top: -2.5px;}
</style> 
</head> 
<body> 
        <link rel="stylesheet" href="css/mdui.css">
<div class="div mdui-card mdui-shadow-10"> 
        <div class="mdui-toolbar">
                <a href="./" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">navigate_before</i></a>
                <span class="mdui-typo-title">消消乐</span>
                <div class="mdui-toolbar-spacer"></div>
<label class="mdui-switch">
启用动画效果&nbsp;
  		<input type="checkbox" onclick="window.location.href='xiaoxiaole.exe?)";
    bool no = false;
    if (str.find("noanimation") != std::string::npos) {
      str.erase(str.begin(), str.begin() + 11);
      std::cout << str << R"('">)";
      no = true;
    }
    else {
      std::cout << "noanimation" << str << R"('" checked/>)";
    }
    
    std::cout << R"(<i class="mdui-switch-icon button"></i>
&nbsp;&nbsp;
	</label>
                <a href="xiaoxiaole.exe?)";
    if (no) {
      std::cout << "noanimation";
    }
    std::cout << "firstclickccscore" << score << R"(secondclickcc" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
                <a href="about.html" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">help</i></a>
              </div>)";
  }

  // 用于输出得分、计算等级、输出进度条
  inline void outScoreBar(double score) {
    if (score < 200)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-blue-300" style="width: )" << score / 2 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-blue-50">
  <span class="mdui-chip-icon mdui-color-blue-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">当前分数：)" << score << R"(&nbsp;&nbsp;&nbsp;目标分数：200&nbsp;&nbsp;&nbsp;当前等级：LEVEL 1</span>
</div>
</div><br>)";
    else if (score < 400)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-pink-300" style="width: )" << score / 4 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-pink-50">
  <span class="mdui-chip-icon mdui-color-pink-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">当前分数：)" << score << R"(&nbsp;&nbsp;&nbsp;目标分数：400&nbsp;&nbsp;&nbsp;当前等级：LEVEL 2</span>
</div>
</div><br>)";
    else if (score < 600)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-amber-300" style="width: )" << score / 6 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-amber-50">
  <span class="mdui-chip-icon mdui-color-amber-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">当前分数：)" << score << R"(&nbsp;&nbsp;&nbsp;目标分数：600&nbsp;&nbsp;&nbsp;当前等级：LEVEL 3</span>
</div>
</div><br>)";
    else if (score < 800)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-light-green-300" style="width: )" << score / 8 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-light-green-50">
  <span class="mdui-chip-icon mdui-color-light-green-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">当前分数：)" << score << R"(&nbsp;&nbsp;&nbsp;目标分数：800&nbsp;&nbsp;&nbsp;当前等级：LEVEL 4</span>
</div>
</div><br>)";
    else if (score < 1000)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-deep-purple-300" style="width: )" << score / 10 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-deep-purple-50">
  <span class="mdui-chip-icon mdui-color-deep-purple-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">当前分数：)" << score << R"(&nbsp;&nbsp;&nbsp;目标分数：1000&nbsp;&nbsp;&nbsp;当前等级：LEVEL 5</span>
</div>
</div><br>)";
    else
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-deep-purple-300" style="width: )" << 100 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-deep-purple-50">
  <span class="mdui-chip-icon mdui-color-deep-purple-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">当前分数：)" << score << R"(&nbsp;&nbsp;&nbsp;您已经满级</span>
</div>
</div><br>)";
  }

  // 输出异常提示
  inline void outException(const char* except) {
    std::cout << R"(<div class="cen"><button class="mdui-btn mdui-color-pink-a400 mdui-ripple">System Error! )" << except << "</button></div><br><br>";
    std::cout << R"(<div class="cen"><p class="content">3s后将开始新的游戏</p>  
<script>  
     var content=document.getElementsByClassName("content")[0];  
     var timeLeft=3;// 5s  
     function tiaozhuan(timeLeft){  
          if(timeLeft>0){        
           setTimeout(function(){  
                timeLeft--;  
                content.innerText=timeLeft+"s后将开始新的游戏";  
                tiaozhuan(timeLeft);  
            },1000);     
          }else{  
               window.location.href="./xiaoxiaole.exe";  
          }  
      }  
      tiaozhuan(timeLeft);  
</script></div>)";
  }

  // 输出自动跳转语句
  inline void outJump(int ms, const char* addr) {
    std::cout << R"(<script>  
     var timeLeft=)" << ms / 100 << R"(;
     function tiaozhuan(timeLeft){  
          if(timeLeft>0){        
           setTimeout(function(){  
                timeLeft--;  
                tiaozhuan(timeLeft);  
            },100);     
          }else{  
               window.location.href=")" << addr << R"(";  
          }  
      }  
      tiaozhuan(timeLeft);  
</script>)";
  }

}

