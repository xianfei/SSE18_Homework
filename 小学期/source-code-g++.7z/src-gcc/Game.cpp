#include "Game.h"

//   2019.7.10   Xianfei, sse of BUPT
//   消消乐游戏核心库  头定义文件

//   ！！！注意：请使用C++17或更新标准编译！！！
//   测试环境：MSVC2019 /std:c++latest 

void Game::handleZero()
{ // 该函数用来处理消除完之后剩余0的问题
  for(int i=row-1;i>=0;i--)
  for (int j = col-1; j >=0; j--) {
    bool top = false;
    while (v[i][j]==0&&!top) {
      for (int k = 0; i-k >0; k++) {
        v[i - k][j] = v[i - k - 1][j];
      }
      v[0][j] = 0;
      int a=0;
      for (int k = 0; i - k > 0; k++) { //检测这个位置上方是否都为0
        a+=v[i - k][j];
      }
      if (!a)top = true;
    }
  }
  std::mt19937 gen(std::random_device{}()); //初始化随机数生成器
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      if (num == 7) {
        if (v[i][j] == 0)v[i][j] = (std::uniform_int_distribution{ 1, num-1 }(gen));
      }
      else {
        if (v[i][j] == 0)v[i][j] = (std::uniform_int_distribution{ 1, num }(gen)); // 用1-4之间的随机数填充每一个元素
      }
    }
  }
}

Game::Game(std::string& str, int row_, int col_, int zl) :row(row_), col(col_),num(zl)
{
  for (int i = 0; i < row; i++) {
    v.push_back(std::vector<int>{});
    for (int j = 0; j < col; j++) {
      v[i].push_back(0); 
    }
  }
  for (int i = 0; i < col * row;i++) {
    v[i / col][i % col] = str[i]-'0';
  }
}

Game::Game(int row_, int col_, int zl):row(row_),col(col_), num(zl)
{
  std::mt19937 gen(std::random_device{}()); //初始化随机数生成器
  for (int i = 0; i < row; i++) {
    v.push_back(std::vector<int>{});
    for (int j = 0; j < col; j++) {
      v[i].push_back(std::uniform_int_distribution{ 1, num }(gen)); // 用1-n之间的随机数填充每一个元素
    }
  }
  // 随机消除一半儿的小木块
  if (num == 7) {
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++) {
        if (v[i][j] == 7 && std::uniform_int_distribution{ 0,1 }(gen))v[i][j] = std::uniform_int_distribution{ 1, num-1 }(gen);
      }
    }
  }
  for (int a = 0; a < 10; a++) {
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++) {
        {
          int step = i;
          for (;;) {
            if (step + 1 == row)break;
            if (v[step][j] == v[step + 1][j]) step++;  //向下检测最长的相等数
            else break;
          }
          if ((step - i) >= 2) {
            for (int k = i; k <= step; k++) {
              v[k][j] = 0;
            }
          }
        }
        {
          int step = j;
          for (;;) {
            if (step + 1 == col)break;
            if (v[i][step] == v[i][step + 1]) step++;  //向右检测最长的相等数
            else break;
          }
          if ((step - j) >= 2) {
            for (int k = j; k <= step; k++) {
              v[i][k] = 0;
            }
          }
        }
      }
    }
    this->handleZero();
  }
}


const std::vector<std::vector<int>>& Game::getVector()
{
  return v;
}

bool Game::change(int x1, int y1, int x2, int y2)
{
  if (x1 < 0 || x1>9)x1 = 0;
  if (x2 < 0 || x2>9)x2 = 0;
  if (y1 < 0 || y1>9)y1 = 0;
  if (y2 < 0 || y2>9)y2 = 0;
  {  // 先换一下试试
    int temp = v[x2][y2];
    v[x2][y2] = v[x1][y1];
    v[x1][y1] = temp;
  }
  bool gameChanged = false;
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < col; j++) {
        if (v[i][j] == 8)continue;
        {
          int step = i;
          for (;;) {
            if (step + 1 == row)break;
            if (v[step][j] == v[step + 1][j]) step++;  //向下检测最长的相等数
            else break;
          }
          if ((step - i) >= 2) {
            score += (int)pow(2, step - i - 1);  //加分规则
            gameChanged = true;
            for (int k = i; k <= step; k++) {
              v[k][j] = 0;
            }
          }
        }
        {
          int step = j;
          for (;;) {
            if (step + 1 == col)break;
            if (v[i][step] == v[i][step + 1]) step++;  //向右检测最长的相等数
            else break;
          }
          if ((step - j) >= 2) {
            score += (int)pow(2, step - j - 1);  //加分规则
            gameChanged = true;
            for (int k = j; k <= step; k++) {
              v[i][k] = 0;
            }
          }
        }
      }
  //this->handleZero();
}
  if (gameChanged)return true;
  else {
   //如果没修改再换回来
      int temp = v[x2][y2];
      v[x2][y2] = v[x1][y1];
      v[x1][y1] = temp;
      return false;
  }
  return false;
}

int& Game::getScore()
{
  return score;
}

std::string Game::arrayToString()
{
  std::string str;
  for (auto i : v) {
    for (auto j : i)str.push_back(j+'0');
  }
  return str;
}

std::pair<int, int> Game::getRowCol()
{
  return {row,col};
}
