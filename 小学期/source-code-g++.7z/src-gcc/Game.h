#pragma once
#include <array>
#include <vector>
#include <cmath>
#include <random>
#include <utility>

//   2019.7.10   Xianfei, sse of BUPT
//   消消乐游戏核心库  头声明文件

//   ！！！注意：请使用C++17或更新标准编译！！！
//   测试环境：MSVC2019 /std:c++latest 

class Game
{
  int row = 0, col = 0; // 游戏行和列
  int score = 0; // 存储游戏得分
  int num; //存储元素的种类个数
  std::vector<std::vector<int>>v;  // 创建存储游戏内容的动态数组
  
public:
  void handleZero(); // 该函数用来处理消除完之后剩余0的问题
  Game(std::string&,int,int,int zl=4); // 使用字符串构造数组的构造函数，用于打开保存的游戏及网页动态处理
  Game(int row, int col, int zl = 4); // 使用随机数构造数组
  const std::vector<std::vector<int>>& getVector(); // 返回存储数据状态的数组
  bool change(int x1,int y1,int x2,int y2);  // 进行游戏操作，如不能操作返回false
  int& getScore();  // 返回当前游戏得分
  std::string arrayToString(); // 将数据数组转为字符串输出，用于打开保存的游戏及网页动态处理
  std::pair<int,int> getRowCol(); // 返回行列值
};

