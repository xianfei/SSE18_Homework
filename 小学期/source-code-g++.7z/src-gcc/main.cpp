#define _CRT_SECURE_NO_WARNINGS  // 禁止报告getenv不安全的错误

//#define CONSOLE  // 用于控制台输出网页源代码，调试使用
//#define NO_CGIMODE  // 用于控制台进行游戏，初期测试核心代码使用

#include "Game.h" // 消消乐游戏核心库

#ifndef NO_CGIMODE

#include <exception>
#include <stdexcept>
#include "CGI.h" // CGI相关映射函数库

int main() {
  Game* game = nullptr;
  try {
#ifndef CONSOLE
    std::string str = getenv("QUERY_STRING"); // 获取CGI环境变量中的query字符串
#else
    // 自己输入一个用于调试的url的query部分
    std::string str = "565";
#endif // !CONSOLE 
    int score = 0;
    if (str.find("score") != std::string::npos) { // 如果url获取的参数不是空的则获取分数
      std::string score_ = str.substr(str.find("score") + 5);
      sscanf(score_.c_str(), "%d", &score);
    }
    CGI::outHead(str,score);
    std::cout << "&nbsp;&nbsp;";
    bool showAnimation = true;
    std::string noanimation;
    if (str.find("noanimation") != std::string::npos) {
      str.erase(str.begin(),str.begin()+11);
      showAnimation = false;
      noanimation = "noanimation";
    }
    int level = score / 200 + 1;  // 每200分升一级
    int ROW = 9, COL = 9, NUM = 5,bianchang = 56; //边长测定数据 10 -> 50  8 -> 63  7-> 73  9 -> 56
    // 等级设定部分
    switch (level) {
    case 1:
      ROW = 7, COL = 7, NUM = 4;
      bianchang = 73;
      break;
    case 2:
      ROW = 7, COL = 8, NUM = 5;
      bianchang = 63;
      break;
    case 3:
      ROW = 8, COL = 8, NUM = 6;
      bianchang = 63;
      break;
    case 4:
      ROW = 9, COL = 9, NUM = 7;
      bianchang = 56;
      break;
    case 5:
      ROW = 7, COL = 8, NUM = 7;
      bianchang = 63;
      break;
    default:
      ROW = 10, COL = 10, NUM = 6;
      bianchang = 50;
      break;
    }
    // 如果url获取的参数是空的则创建新的游戏
    if (str.empty()) { 
      game = new Game(ROW, COL,NUM);
      std::string array = game->arrayToString();
      for (int i = 0; i < game->getRowCol().first; i++) {
        for (int j = 0; j < game->getRowCol().second; j++) {
          if (game->getVector()[i][j] == 7) {
            std::cout << R"(<img class="mdui-shadow-0" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
          else {
            std::cout << R"(<img class="mdui-btn-raised mdui-ripple mdui-shadow-0" onclick="window.location.href=')" << "xiaoxiaole.exe?" << noanimation << array << "firstclick" << i << j << "score" << game->getScore() << R"('" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
        }
        std::cout << "<br>&nbsp;&nbsp;";
      }
      CGI::outScoreBar(0);
    }
    // 用于处理动画中消除0的动画
    else if (str.find("handlezero") != std::string::npos) {  
      std::string s(str);
      s.erase(s.find("handlezero"));
      if (s.size() != ROW * COL)game = new Game(ROW, COL, NUM);
      else game= new Game(s, ROW, COL, NUM);
      game->getScore()=score;
      game->handleZero();
      for (int i = 0; i < game->getRowCol().first; i++) {
        for (int j = 0; j < game->getRowCol().second; j++) {
          if (game->getVector()[i][j] == 7) {
            std::cout << R"(<img class="mdui-shadow-0" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
          else {
            std::cout << R"(<img class="mdui-btn-raised mdui-ripple mdui-shadow-0" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
        }
        std::cout << "<br>&nbsp;&nbsp;";
      }
      std::string array = game->arrayToString();
      std::string addr;
      addr = "./xiaoxiaole.exe?" + array + "firstclickccscore"+std::to_string(game->getScore())+"secondclickcc";
      CGI::outScoreBar(game->getScore());
      CGI::outJump(200, addr.c_str());
      
    }
    // 如果url获取的参数含有第二次点击的信息  并且启用动画
    else if (str.find("secondclick") != std::string::npos && showAnimation) { 
      std::string s(str);
      s.erase(s.find("firstclick"));
      if (s.size() != ROW * COL)game = new Game(ROW, COL, NUM);
      else game = new Game(s, ROW, COL, NUM);
      std::string firstclick = str.substr(str.find("firstclick") + 10, str.find("score"));
      game->getScore() = score;
      std::string secondclick = str.substr(str.find("secondclick") + 11);
      bool changed;
      if ((abs((firstclick[0] - '0') - (secondclick[0] - '0')) == 1 && (firstclick[1] - '0' == secondclick[1] - '0')) || (abs((firstclick[1] - '0') - (secondclick[1] - '0')) == 1 && (firstclick[0] - '0' == secondclick[0] - '0'))|| firstclick[0]=='c') {
        changed = game->change(firstclick[0] - '0', firstclick[1] - '0', secondclick[0] - '0', secondclick[1] - '0');
      }
      else {
        changed = false;
      }
      std::string array = game->arrayToString();
      if (changed) {
        for (int i = 0; i < game->getRowCol().first; i++) {
          for (int j = 0; j < game->getRowCol().second; j++) {
            if (game->getVector()[i][j] == 7) {
              std::cout << R"(<img class="mdui-shadow-0" src="4_0)";
              std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
            }
            else {
              std::cout << R"(<img class="mdui-btn-raised mdui-ripple mdui-shadow-0" src="4_0)";
              std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
            }
          }
          std::cout << "<br>&nbsp;&nbsp;";
        }
        std::string addr;
        addr = "./xiaoxiaole.exe?" + array + "handlezero" + "score" + std::to_string(game->getScore());
        CGI::outScoreBar(game->getScore());
        CGI::outJump(300, addr.c_str());
      }
      else {
        for (int i = 0; i < game->getRowCol().first; i++) {
          for (int j = 0; j < game->getRowCol().second; j++) {
            if (game->getVector()[i][j] == 7) {
              std::cout << R"(<img class="mdui-shadow-0" src="4_0)";
              std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
            }
            else {
              std::cout << R"(<img class="mdui-btn-raised mdui-ripple mdui-shadow-0" onclick="window.location.href=')" << "xiaoxiaole.exe?" << array << "firstclick" << i << j << "score" << game->getScore() << R"('" src="4_0)";
              std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
            }
          }
          std::cout << "<br>&nbsp;&nbsp;";
        }
        if (firstclick[0] != 'c')std::cout << "此处无法进行交换！";
        CGI::outScoreBar(game->getScore());
      }
    }
    // 如果url获取的参数含有第二次点击的信息  并且不启用动画
    else if (str.find("secondclick") != std::string::npos && !showAnimation) {
      std::string s(str);
      if (s.size() != ROW * COL)game = new Game(ROW, COL, NUM);
      else game = new Game(s, ROW, COL, NUM);
      std::string firstclick = str.substr(str.find("firstclick") + 10, str.find("score"));
      std::string score = str.substr(str.find("score") + 5, str.find("secondclick"));
      sscanf(score.c_str(), "%d", &game->getScore());
      std::string secondclick = str.substr(str.find("secondclick") + 11);
      bool changed;
      if ((abs((firstclick[0] - '0') - (secondclick[0] - '0')) == 1 && (firstclick[1] - '0' == secondclick[1] - '0')) || (abs((firstclick[1] - '0') - (secondclick[1] - '0')) == 1 && (firstclick[0] - '0' == secondclick[0] - '0')) || firstclick[0] == 'c') {
        changed = game->change(firstclick[0] - '0', firstclick[1] - '0', secondclick[0] - '0', secondclick[1] - '0');
        do game->handleZero();
        while (game->change(0, 0, 0, 0));
      }
      else {
        changed = false;
      }      
      std::string array = game->arrayToString();
      for (int i = 0; i < game->getRowCol().first; i++) {
        for (int j = 0; j < game->getRowCol().second; j++) {
          if (game->getVector()[i][j] == 7) {
            std::cout << R"(<img class="mdui-shadow-0" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
          else {
            std::cout << R"(<img class="mdui-btn-raised mdui-ripple mdui-shadow-0" onclick="window.location.href=')" << "xiaoxiaole.exe?noanimation" << array << "firstclick" << i << j << "score" << game->getScore() << R"('" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
        }
        std::cout << "<br>&nbsp;&nbsp;";
      }
      if (!changed&& (firstclick[0] != 'c'))std::cout << "此处无法进行交换！";
      CGI::outScoreBar(game->getScore());
    }
    // 如果url获取的参数只含有第一次点击的信息
    else if (str.find("firstclick") != std::string::npos) {  
      std::string s(str);
      s.erase(s.find("firstclick"));
      if (s.size() != ROW * COL)game = new Game(ROW, COL, NUM);
      else game = new Game(s, ROW, COL, NUM);
      std::string firstclick = str.substr(str.find("firstclick") + 10);
      game->getScore() = score;
      for (int i = 0; i < game->getRowCol().first; i++) {
        for (int j = 0; j < game->getRowCol().second; j++) {
          if (game->getVector()[i][j] == 7) {
            std::cout << R"(<img class="mdui-shadow-0" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
          else {
            if (i == (firstclick[0] - '0') && j == (firstclick[1] - '0'))
              std::cout << R"(<img class="mdui-btn-raised mdui-ripple  mdui-shadow-5" onclick="window.location.href=')";
            else
              std::cout << R"(<img class="mdui-btn-raised mdui-ripple  mdui-shadow-0" onclick="window.location.href=')";
            std::cout << "xiaoxiaole.exe?" << noanimation << str << "secondclick" << i << j << R"('" src="4_0)";
            std::cout << game->getVector()[i][j] << R"(.jpg"  height=")" << bianchang << R"(" width=")" << bianchang << R"(" /></a>&nbsp;)";
          }
        }
        std::cout << "<br>&nbsp;&nbsp;";
      }
      // std::cout << "您已经选择了第" << (firstclick[0] - '0')+1 << "行的第"<< (firstclick[1] - '0')+1 << "个";
      CGI::outScoreBar(game->getScore());
    }
    // 如果这些情况都不符合，则抛出异常
    else {
      throw std::runtime_error( "Illegal Argument Exception" );
    }
  }
  catch (std::exception& e) {
    CGI::outException(e.what());
  }catch (...) {
    CGI::outException("unkown exception");
  }
  delete game;
  printf("</div></body>\n</html>");
  return 0;
}



#else
#include <iostream>
int main() {
  Game game(8, 8);
  for (;;) {
    for (auto i : game.getVector()) {
      for (auto j : i)std::cout << j << " ";
      std::cout << std::endl;
    }
    std::cout << "Please input which two you want to exchange(x1,y1,x2,y2)" << std::endl;
    int num[4];
    std::cin >> num[0] >> num[1] >> num[2] >> num[3];
    std::cout << std::boolalpha << game.change(num[0], num[1], num[2], num[3]) << std::endl;
    do {
      for (auto i : game.getVector()) {
        for (auto j : i)std::cout << j << " ";
        std::cout << std::endl;
      }
      std::cout << std::endl;
      game.handleZero();
      for (auto i : game.getVector()) {
        for (auto j : i)std::cout << j << " ";
        std::cout << std::endl;
      }
      std::cout << std::endl;
    } while (game.change(0, 0, 0, 0));
    std::cout << "Your Score is：" << game.getScore() << std::endl;
  }
  return 0;
}
#endif 


