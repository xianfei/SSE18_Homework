# Readme

1. compile it using g++

```
g++-9 CGI.h Game.h Game.cpp main.cpp -std=c++17 -o2 -o xiaoxiaole.exe
```

2. change permission for execute 

```
chmod +x /var/www/html/xiaoxiaole/xiaoxiaole.exe 
```

3. set Apache for supporting cgi

enable cgi mods (search on the Internet)

make a file named '.htaccess' and put below codes:

```
AddHandler cgi-script .cgi .exe
Options +ExecCGI
```