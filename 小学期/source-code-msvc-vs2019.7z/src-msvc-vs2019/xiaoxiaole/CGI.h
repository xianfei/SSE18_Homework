#pragma once
#include <string>
#include <iostream>
namespace CGI
{
  
  // ���CGI��Ҫ��HTTPͷ�ļ� ��HTML�����ļ�ͷ��
  inline void outHead(std::string str,int score) {
    printf("Content-type:text/html\n\n");
    std::cout << R"(<html> 
<head> 
<title>C++������</title> 
<style> 
body{
    background-color: #CCCCCC;
    background-image: url('bg.png');
    background-repeat: no-repeat;
    background-attachment: fixed; 
    background-size: cover;
}
.cen{ text-align:center;font-weight:500;} 
.div{     position: absolute;
    margin-top: 50px;
    width: 550px;
    left: 50%;
    margin-left: -275px;}
.button{margin-top: -2.5px;}
</style> 
</head> 
<body> 
        <link rel="stylesheet" href="css/mdui.css">
<div class="div mdui-card mdui-shadow-10"> 
        <div class="mdui-toolbar">
                <a href="./" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">navigate_before</i></a>
                <span class="mdui-typo-title">������</span>
                <div class="mdui-toolbar-spacer"></div>
<label class="mdui-switch">
���ö���Ч��&nbsp;
  		<input type="checkbox" onclick="window.location.href='xiaoxiaole.exe?)";
    bool no = false;
    if (str.find("noanimation") != std::string::npos) {
      str.erase(str.begin(), str.begin() + 11);
      std::cout << str << R"('">)";
      no = true;
    }
    else {
      std::cout << "noanimation" << str << R"('" checked/>)";
    }
    
    std::cout << R"(<i class="mdui-switch-icon button"></i>
&nbsp;&nbsp;
	</label>
                <a href="xiaoxiaole.exe?)";
    if (no) {
      std::cout << "noanimation";
    }
    std::cout << "firstclickccscore" << score << R"(secondclickcc" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
                <a href="about.html" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">help</i></a>
              </div>)";
  }

  // ��������÷֡�����ȼ������������
  inline void outScoreBar(double score) {
    if (score < 200)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-blue-300" style="width: )" << score / 2 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-blue-50">
  <span class="mdui-chip-icon mdui-color-blue-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">��ǰ������)" << score << R"(&nbsp;&nbsp;&nbsp;Ŀ�������200&nbsp;&nbsp;&nbsp;��ǰ�ȼ���LEVEL 1</span>
</div>
</div><br>)";
    else if (score < 400)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-pink-300" style="width: )" << score / 4 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-pink-50">
  <span class="mdui-chip-icon mdui-color-pink-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">��ǰ������)" << score << R"(&nbsp;&nbsp;&nbsp;Ŀ�������400&nbsp;&nbsp;&nbsp;��ǰ�ȼ���LEVEL 2</span>
</div>
</div><br>)";
    else if (score < 600)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-amber-300" style="width: )" << score / 6 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-amber-50">
  <span class="mdui-chip-icon mdui-color-amber-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">��ǰ������)" << score << R"(&nbsp;&nbsp;&nbsp;Ŀ�������600&nbsp;&nbsp;&nbsp;��ǰ�ȼ���LEVEL 3</span>
</div>
</div><br>)";
    else if (score < 800)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-light-green-300" style="width: )" << score / 8 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-light-green-50">
  <span class="mdui-chip-icon mdui-color-light-green-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">��ǰ������)" << score << R"(&nbsp;&nbsp;&nbsp;Ŀ�������800&nbsp;&nbsp;&nbsp;��ǰ�ȼ���LEVEL 4</span>
</div>
</div><br>)";
    else if (score < 1000)
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-deep-purple-300" style="width: )" << score / 10 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-deep-purple-50">
  <span class="mdui-chip-icon mdui-color-deep-purple-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">��ǰ������)" << score << R"(&nbsp;&nbsp;&nbsp;Ŀ�������1000&nbsp;&nbsp;&nbsp;��ǰ�ȼ���LEVEL 5</span>
</div>
</div><br>)";
    else
      std::cout << R"(<div class="mdui-progress">
  <div class="mdui-progress-determinate mdui-color-deep-purple-300" style="width: )" << 100 << R"(%;"></div>
</div>
<div class="cen">
<br>&nbsp;
<div class="mdui-chip mdui-color-deep-purple-50">
  <span class="mdui-chip-icon mdui-color-deep-purple-400"><i class="mdui-icon material-icons">label</i></span>
  <span class="mdui-chip-title">��ǰ������)" << score << R"(&nbsp;&nbsp;&nbsp;���Ѿ�����</span>
</div>
</div><br>)";
  }

  // ����쳣��ʾ
  inline void outException(const char* except) {
    std::cout << R"(<div class="cen"><button class="mdui-btn mdui-color-pink-a400 mdui-ripple">System Error! )" << except << "</button></div><br><br>";
    std::cout << R"(<div class="cen"><p class="content">3s�󽫿�ʼ�µ���Ϸ</p>  
<script>  
     var content=document.getElementsByClassName("content")[0];  
     var timeLeft=3;// 5s  
     function tiaozhuan(timeLeft){  
          if(timeLeft>0){        
           setTimeout(function(){  
                timeLeft--;  
                content.innerText=timeLeft+"s�󽫿�ʼ�µ���Ϸ";  
                tiaozhuan(timeLeft);  
            },1000);     
          }else{  
               window.location.href="./xiaoxiaole.exe";  
          }  
      }  
      tiaozhuan(timeLeft);  
</script></div>)";
  }

  // ����Զ���ת���
  inline void outJump(int ms, const char* addr) {
    std::cout << R"(<script>  
     var timeLeft=)" << ms / 100 << R"(;
     function tiaozhuan(timeLeft){  
          if(timeLeft>0){        
           setTimeout(function(){  
                timeLeft--;  
                tiaozhuan(timeLeft);  
            },100);     
          }else{  
               window.location.href=")" << addr << R"(";  
          }  
      }  
      tiaozhuan(timeLeft);  
</script>)";
  }

}

